// ManageProducts.tsx
import React from 'react';

const ManageProducts: React.FC = () => {
  return <div>Manage Products Page</div>;
};

export default ManageProducts;